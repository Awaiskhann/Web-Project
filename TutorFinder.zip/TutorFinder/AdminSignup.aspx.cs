﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class AdminSignup : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, System.EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\PC\Desktop\Haseeb Ziaa Bc123095\TutorFinder\App_Data\Databasefinal.mdf;Integrated Security=True");

        con.Open();

        SqlCommand com = new SqlCommand("insert into [adminreg] (username,password,retype) values('" + username.Text + "','" + password.Text + "','" + retype.Text + "')", con);

        com.ExecuteNonQuery();



        Response.Redirect("AdminLogin.aspx");

        con.Close();
    }
    

}