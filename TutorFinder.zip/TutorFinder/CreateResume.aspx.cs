﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class CreateResume : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\PC\Desktop\TutorFinder\App_Data\Database.mdf;Integrated Security=True");

        con.Open();

        SqlCommand com = new SqlCommand("insert into [Resume] (FirstName,LastName,City,Mobile,Experince,Email) values('" + first.Text + "','" + last.Text + "','" + city.Text + "','" + mob.Text + "','" + exp.Text + "','" +  email.Text + "' )", con);

        com.ExecuteNonQuery();



        Response.Redirect("login.aspx");

        con.Close();
    }
}