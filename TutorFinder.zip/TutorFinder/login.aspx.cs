﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;



using System.Data;
using System.Data.SqlClient;


public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }   
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\PC\Desktop\Haseeb Ziaa Bc123095\TutorFinder\App_Data\Databasefinal.mdf;Integrated Security=True");
        con.Open();
        SqlCommand cmd = new SqlCommand("select COUNT(*)FROM studentlogin WHERE username='" + username.Text + "' and password='" + password.Text + "'");
        cmd.Connection = con;
        int OBJ = Convert.ToInt32(cmd.ExecuteScalar());
        if (OBJ > 0)
        {
            //Session["name"] = TextBox1.Text;
            Response.Redirect("StudentPannel.aspx");
            
        }
        //////else
        //////{
        //////    Label1.Text = "Invalid username or password";
        //////    this.Label1.ForeColor = Color.Red;

        //////}

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminLogin.aspx");
    }
}
